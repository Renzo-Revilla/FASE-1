package Ejercicio7;

public class OrdenamientoMejorado {
    private static final int UMBRAL = 16;

    public static void mergeSort(int[] arr, int left, int right) {
        if (right - left <= UMBRAL) {
            insertionSort(arr, left, right);
            return;
        }

        int mid = left + (right - left) / 2;
        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);
        merge(arr, left, mid, right);
    }

    private static void insertionSort(int[] arr, int left, int right) {
        for (int i = left + 1; i <= right; i++) { // O(n)
            int key = arr[i]; // O(1)
            int j = i - 1;
            while (j >= left && arr[j] > key) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
    }

    private static void merge(int[] arr, int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid; // O(1)

        int[] leftArr = new int[n1]; // O(n)
        int[] rightArr = new int[n2]; // O(n)

        System.arraycopy(arr, left, leftArr, 0, n1); // O(n)
        System.arraycopy(arr, mid + 1, rightArr, 0, n2); // O(n)

        int i = 0, j = 0, k = left; // O(1)

        while (i < n1 && j < n2) { // O(n)
            arr[k++] = (leftArr[i] <= rightArr[j]) ? leftArr[i++] : rightArr[j++]; // O(1)
        }

        while (i < n1) {
            arr[k++] = leftArr[i++];
        }

        while (j < n2) {
            arr[k++] = rightArr[j++];
        }
    }

    public static void main(String[] args) {
        int[] arr = {38, 27, 43, 3, 9, 82, 10}; // O(1)
        mergeSort(arr, 0, arr.length - 1); // O(n log n)

        for (int num : arr) { // O(n)
            System.out.print(num + " "); // O(1)
        }
    }
}
