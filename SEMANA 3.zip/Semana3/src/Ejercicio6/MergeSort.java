package Ejercicio6;

public class MergeSort {
    public static void mergeSort(int[] arr, int left, int right) {
        if (left < right) { // O(1)
            int mid = left + (right - left) / 2; // O(1)

            // Dividir en dos mitades
            mergeSort(arr, left, mid); // O(log n)
            mergeSort(arr, mid + 1, right); // O(log n)

            // Mezclar las dos mitades ordenadas
            merge(arr, left, mid, right); // O(n)
        }
    }

    private static void merge(int[] arr, int left, int mid, int right) {
        int n1 = mid - left + 1; // O(1)
        int n2 = right - mid; // O(1)

        int[] leftArr = new int[n1]; // O(n)
        int[] rightArr = new int[n2]; // O(n)

        System.arraycopy(arr, left, leftArr, 0, n1); // O(n)
        System.arraycopy(arr, mid + 1, rightArr, 0, n2); // O(n)

        int i = 0, j = 0, k = left; // O(1)

        while (i < n1 && j < n2) { // O(n)
            if (leftArr[i] <= rightArr[j]) { // O(1)
                arr[k++] = leftArr[i++]; // O(1)
            } else {
                arr[k++] = rightArr[j++]; // O(1)
            }
        }

        while (i < n1) { // O(n)
            arr[k++] = leftArr[i++]; // O(1)
        }

        while (j < n2) { // O(n)
            arr[k++] = rightArr[j++]; // O(1)
        }
    }

    public static void main(String[] args) {
        int[] arr = {38, 27, 43, 3, 9, 82, 10}; // O(1)
        mergeSort(arr, 0, arr.length - 1); // O(n log n)

        for (int num : arr) { // O(n)
            System.out.print(num + " "); // O(1)
        }
    }
}
